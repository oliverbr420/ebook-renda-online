# 📘 Landing Page - Ebook Renda Online

Este repositório contém uma landing page simples para divulgar e vender seu ebook.

## 🚀 Como usar

1. Faça upload dos arquivos para o GitHub neste repositório.  
2. Vá em **Configurações > Pages**.  
3. Selecione a branch **main** e a pasta **/(root)**.  
4. Clique em salvar.  

Sua página estará disponível em:  
```
https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/
```

## ✨ Personalização
- Edite o arquivo `index.html` para trocar o título, descrição e link do botão.  
- Altere `assets/style.css` para mudar cores e estilos.  
